package net.nexus.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.nexus.client.module.ModuleManager;
import net.nexus.client.ui.NexusClickGui;
import org.lwjgl.glfw.GLFW;

public final class NexusClient implements ClientModInitializer {
    public static final String MOD_ID = "nexus";
    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.nexus.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new NexusClickGui());
                }
            }
        });

        System.out.println("[NEXUS] Visual Client initialized.");
    }
}
