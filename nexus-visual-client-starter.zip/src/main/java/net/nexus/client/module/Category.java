package net.nexus.client.module;

public enum Category {
    VISUALS("Визуалы"),
    PVP("PvP"),
    HUD("HUD"),
    COSMETICS("Косметика"),
    MISC("Разное");

    private final String displayName;
    Category(String displayName) { this.displayName = displayName; }
    public String displayName() { return displayName; }
}
