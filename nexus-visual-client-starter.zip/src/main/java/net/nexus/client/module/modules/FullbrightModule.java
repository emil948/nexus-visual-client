package net.nexus.client.module.modules;

import net.nexus.client.module.Category;
import net.nexus.client.module.NexusModule;

public final class FullbrightModule extends NexusModule {
    public FullbrightModule() {
        super("Fullbright", "Повышенная яркость мира", Category.VISUALS);
    }
}
