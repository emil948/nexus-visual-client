package net.nexus.client.module.modules;

import net.nexus.client.module.Category;
import net.nexus.client.module.NexusModule;

public final class WorldParticlesModule extends NexusModule {
    public WorldParticlesModule() {
        super("Частицы мира", "Косметические частицы вокруг игрока", Category.VISUALS);
    }
}
