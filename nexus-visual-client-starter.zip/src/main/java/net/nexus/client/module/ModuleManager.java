package net.nexus.client.module;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.nexus.client.module.modules.CoordinatesHudModule;
import net.nexus.client.module.modules.FullbrightModule;
import net.nexus.client.module.modules.PingHudModule;
import net.nexus.client.module.modules.WorldParticlesModule;

public final class ModuleManager {
    private static final List<NexusModule> MODULES = new ArrayList<>();
    private static boolean initialized;

    private ModuleManager() {}

    public static void init() {
        if (initialized) return;
        initialized = true;
        MODULES.add(new FullbrightModule());
        MODULES.add(new CoordinatesHudModule());
        MODULES.add(new PingHudModule());
        MODULES.add(new WorldParticlesModule());
    }

    public static List<NexusModule> all() {
        return Collections.unmodifiableList(MODULES);
    }
}
