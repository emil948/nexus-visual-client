package net.nexus.client.module.modules;

import net.nexus.client.module.Category;
import net.nexus.client.module.NexusModule;

public final class CoordinatesHudModule extends NexusModule {
    public CoordinatesHudModule() {
        super("Координаты", "Показывать XYZ игрока", Category.HUD);
    }
}
