package net.nexus.client.module.modules;

import net.nexus.client.module.Category;
import net.nexus.client.module.NexusModule;

public final class PingHudModule extends NexusModule {
    public PingHudModule() {
        super("Ping HUD", "Показывать задержку до сервера", Category.HUD);
    }
}
