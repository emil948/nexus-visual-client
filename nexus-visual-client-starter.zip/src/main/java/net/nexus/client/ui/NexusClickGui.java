package net.nexus.client.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.nexus.client.module.Category;
import net.nexus.client.module.ModuleManager;
import net.nexus.client.module.NexusModule;

public final class NexusClickGui extends Screen {
    private static final int BG = 0xF20B0715;
    private static final int PANEL = 0xFF171027;
    private static final int PURPLE = 0xFF9B4DFF;
    private static final int WHITE = 0xFFF4EEFF;
    private static final int MUTED = 0xFFB9A9D8;

    public NexusClickGui() {
        super(Text.literal("NEXUS Visual Client"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int left = Math.max(16, width / 2 - 220);
        int top = Math.max(16, height / 2 - 150);
        int right = Math.min(width - 16, left + 440);
        int bottom = Math.min(height - 16, top + 300);

        context.fill(left, top, right, bottom, BG);
        context.fill(left, top, right, top + 34, PANEL);
        context.fill(left, top, left + 3, bottom, PURPLE);
        context.drawText(textRenderer, "NEXUS", left + 14, top + 10, PURPLE, true);
        context.drawText(textRenderer, "VISUAL CLIENT  •  1.21.11", left + 78, top + 11, WHITE, false);
        context.drawText(textRenderer, "МОДУЛИ", left + 14, top + 46, PURPLE, false);

        int y = top + 64;
        Category current = null;
        for (NexusModule module : ModuleManager.all()) {
            if (y > bottom - 18) break;
            if (module.category() != current) {
                current = module.category();
                context.drawText(textRenderer, current.displayName(), left + 14, y, MUTED, false);
                y += 16;
            }
            context.fill(left + 10, y - 3, right - 10, y + 14, 0xAA211638);
            context.drawText(textRenderer, module.name(), left + 18, y, WHITE, false);
            String state = module.isEnabled() ? "ВКЛ" : "ВЫКЛ";
            int color = module.isEnabled() ? PURPLE : MUTED;
            context.drawText(textRenderer, state, right - 52, y, color, false);
            y += 20;
        }

        context.drawText(textRenderer, "Нажми на строку, чтобы переключить модуль", left + 14, bottom - 18, MUTED, false);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int left = Math.max(16, width / 2 - 220);
            int top = Math.max(16, height / 2 - 150);
            int y = top + 64;
            Category current = null;
            for (NexusModule module : ModuleManager.all()) {
                if (module.category() != current) {
                    current = module.category();
                    y += 16;
                }
                if (mouseX >= left + 10 && mouseX <= left + 430
                        && mouseY >= y - 3 && mouseY <= y + 14) {
                    module.toggle();
                    return true;
                }
                y += 20;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
